#include <stdio.h>
#include <locale.h>

int main(void)
{
    setlocale(LC_ALL, "");

    printf("Utilizando caracteres e acentua��o da l�ngua portuguesa!\n");

    return 0;
}
