//Imprime n�meros de 0 a 10

#include <stdio.h>

int main(void)
{
    int i = 0;

    do
    {
        printf("%d\n", i);
        i++;
    }while(i <= 10);

    return 0;
}
