#include <stdio.h>

int main(void)
{
    printf("Utilizando caracteres e acentua%c%co da l%cngua portuguesa!\n", 135, 198, 161);

    return 0;
}
