//Imprime os n�meros de 0 a 10.

#include <stdio.h>

int main(void)
{
    int cont;

    for(cont=0; cont<=10; cont++)
    {
        printf("%d\n", cont);
    }
    return 0;
}
