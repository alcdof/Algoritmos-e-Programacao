//Imprime n�meros de 0 a 10

#include <stdio.h>

int main(void)
{
    int i = 0;

    while(i <= 10)
    {
        printf("%d\n", i);
        i++;
    }

    return 0;
}
